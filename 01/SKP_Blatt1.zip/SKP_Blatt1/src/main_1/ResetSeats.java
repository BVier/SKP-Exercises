package main_1;

import java.util.ArrayList;
import java.util.List;

import common.SeatsAccess;

public class ResetSeats {

	/**
	 * Resets all the seats in the file "seats.dat" to 0.
	 * @param args
	 */
	public static void main(String[] args) {
		int n = 200;	// the number of seats
		SeatsAccess.writeSeats("seats.dat", initSeats(n));
	}

	private static List<Integer> initSeats(int n) {
		List<Integer> s = new ArrayList<Integer>();
		for (int i=0; i<n; i++) {
			s.add(0);
		}
		return s;
	}
	
}
