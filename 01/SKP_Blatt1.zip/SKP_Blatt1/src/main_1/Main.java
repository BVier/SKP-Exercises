package main_1;

import common.SeatsAccess;

public class Main {
	
	private static String seatsFilename = "seats.dat";
	private static int n = 200;	// the number of seats
	
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		int reserved=0;
		while(reserve()) {
			reserved++;
		}
		long totalTime = System.currentTimeMillis() - startTime;
		System.out.println("Kartenschalter: " + reserved + " Karten verkauft");
		System.out.println("Benoetigte Zeit: " + totalTime + " ms");
	}
	
	private static boolean reserve() {
		int seat = -1;
		for (int i=0; i<n; i++) {
			if (SeatsAccess.getSeat(seatsFilename, i)==0) {
				seat = i;
				break;
			}
		}
		if (seat!=-1) {
			// reserve seat
			SeatsAccess.writeSeat(seatsFilename, seat, 1);
			System.out.println("Seat " + seat + " reserved!");
			return true;
		} else {
			System.out.println("Seat could not be reserved!");
			return false;
		}
	}
}
